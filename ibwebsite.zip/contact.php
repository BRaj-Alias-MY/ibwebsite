<?php 
session_start();
if(isset($_POST['send']))
{
$name  = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$comment = $_POST['comment'];

$to = "contact@interviewbuddy.net,murali.yeduresapu@schemaxtech.com";
$subject = "Contact form query | InterviewBuddy North America";

$txt .= "Name : " . $name . "\r\n";
$txt .=  "Email: " . $email . "\r\n";
$txt .=  "Phone: " . $phone . "\r\n";
$txt .=  "Message: " . $comment;
 

$headers .= "From: ".$email."" . "\r\n";
if(mail($to,$subject,$txt,$headers))
{
	$_SESSION['success'] = "E-mail sent successfully! Our Team will contact you soon..!";
}
else 
{
		$_SESSION['success']= "E-mail sent successfully! Our Team will contact you soon..!";
}
}
?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
      <link rel="shortcut icon" href="ib.ico">
    <!-- Author Meta -->
    <meta name="author" content="">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>InterviewBuddy</title>
    <link rel="shortcut icon" href="logofco.ico">
	<link rel="icon" href="logogif.gif" type="image/gif" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">

    <!--
CSS
============================================= -->

    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
<style>
.section-gap-full
{
padding: 53px 0;
}
.myclass 
{
    margin-top: -156px;
    position: relative;
}
.nav-link, .navbar {
    padding: 0.7rem 1rem;
}
</style>
</head>

<body>

    <!-- Preloader -->
    <div id="loader-wrapper">
        <div id="loader"></div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>
  <!-- Start header section -->
    <header class="header-area" id="header-area">
        <div class="dope-nav-container breakpoint-off">
            <div class="container">
                <div class="row">
                    <!-- dope Menu -->
                    <nav class="dope-navbar justify-content-between" id="dopeNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html">
                            <img src="img/logo.png" alt="">
                        </a>

                        <!-- Navbar Toggler -->
                        <div class="dope-navbar-toggler">
                            <span class="navbarToggler">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </div>

                        <!-- Menu -->
                        <div class="dope-menu">

                            <!-- close btn -->
                            <div class="dopecloseIcon">
                                <div class="cross-wrap">
                                    <span class="top"></span>
                                    <span class="bottom"></span>
                                </div>
                            </div>

                            <!-- Nav Start -->
                            <div class="dopenav">
                                  <ul id="nav">
                                    <li>
                                        <a href="index.html#banner-section">Home</a>
                                    </li>
                                    <li>
                                        <a href="index.html#about-section">About</a>
                                    </li>
                                    <li>
                                        <a href="index.html#feature-section">Students</a>
                                    </li>
									
									  <li>
                                        <a href="index.html#campus-section">Campus</a>
                                    </li>
									
                                    <li>
                                        <a href="index.html#price-section">Price</a>
                                    </li>
                                    <li>
                                        <a href="index.html#testimonial-section">Testimonial</a>
                                    </li>
									  
									
                                    <li style="display:none;">
                                        <a href="#download-section">Download</a>
                                    </li>
                                </ul>

                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Start header section -->

    <!-- Start page-top-banner section -->
    <section class="page-top-banner section-gap-full relative" data-stellar-background-ratio="0.5">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row section-gap-half">
                <div class="col-lg-12 text-center">
                    <h1>Contact Now</h1>
                    <h4>Drop an E-Mail Right Away..!</h4>
                </div>
            </div>
        </div>
    </section>
    <!-- End about-top-banner section -->

    <!-- Start contact section -->
      <!-- Start contact section -->
    <section class="contact-section contact-page-section padding-top-120" id="contact-section">
        <div class="container">
            <div class="row address-wrap justify-content-center">
                <div class="col-lg-3 col-md-4 col-sm-6 single-address-col">
                    <div class="div">
                        <i class="ti ti-mobile"></i>
                        <p>
                            +880-888888888
                            
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 single-address-col">
                    <div class="div">
                        <i class="ti ti-map-alt"></i>
                        <p>
                            North America
                            
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-12 single-address-col">
                    <div class="div">
                        <i class="ti ti-email"></i>
                        <p>
                            contact@interviewbuddy.net
                           
                        </p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center form-row">
                <div class="col-lg-9">
                    <form id="contact-form" action="" method="POST">
                        <div class="row contact-form-wrap justify-content-center">
                            <div class="col-md-6 contact-name form-col">
                                <input name="name" id="name" class="form-control" type="text" placeholder="Name*"
                                    onfocus="this.placeholder=''" required onblur="this.placeholder='Name*'">
                            </div>
                            <div class="col-md-6 contact-email form-col">
                                <input name="email" id="mail" required class="form-control" type="email" placeholder="E-mail*"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='Email*'">
                            </div>
							
							 <div class="col-md-12 contact-email form-col">
                                <input name="phone" id="phone" required class="form-control" type="text" placeholder="Phone Number *"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='phone*'">
                            </div>
                            <div class="col-lg-12">
                                <textarea name="comment" id="comment" class="form-control" rows="8" placeholder="Message"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='Message*'"></textarea>
                            </div>
                            <input type="submit" style="cursor:pointer;" class="primary-btn" value="Send Message" id="send" name="send">
							
                            
                        </div>
                    
                </div>
            </div>
			 <br/> <br/>
				<div style="text-align:center;color:red;">
				 <?php 
							 echo 	@$_SESSION['success'];
							 ?>
							 
				</div>
							
        </div>
    </section>
    <!-- End contact section -->
    <!-- End contact section -->

    <!-- Start footer section -->
  <footer class="footer-section section-gap-half">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 footer-left">
                    <a href="#">
                        <img src="img/logo2.png" alt="">
                    </a>
                    <p class="copyright-text">&copy; 2019  
                        <i class="fa fa-copyright" aria-hidden="true"></i> By
                        <a href="" target="_blank"> InterviewBuddy</a>
                    </p>
                </div>
                <div class="col-lg-7">
                    <ul id="social">
                        <li>
                            <a target="_blank" href="https://facebook.com/intrvwbuddy">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="https://twitter.com/intrvwbuddy">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                       
                        <li>
                            <a target="_blank" href="https://instagram.com/intrvwbuddy">
                                <i class="fa fa-instagram" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                 
                </div>
            </div>
        </div>
    </footer>
    <!-- End footer section -->

    <div class="scroll-top">
        <i class="ti-angle-up"></i>
    </div>
	
	</form>

    <!--
JS
============================================= -->
    <script src="js/vendor/jquery-2.2.4.min.js"></script>
    <script src="js/vendor/popper.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/jquery.parallax-scroll.js"></script>
    <script src="js/dopeNav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/main.js"></script>
	<script>
	$(function(){
  $(window).scroll(function(){
    var aTop = $('.header-area').height();
    if($(this).scrollTop()>=aTop){
       // alert('header just passed.');
	   $('.dope-nav-container').find('a').css('color','black');
        // instead of alert you can use to show your ad
        // something like $('#footAd').slideup();
    }
	else 
	{
	$('.dope-nav-container').find('a').css('color','#fff');
	}
  });
});
	</script>
</body>

</html>