<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/fav.png">
    <!-- Author Meta -->
    <meta name="author" content="">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>Dope - Creative Multipurpose HTML Template</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">

    <!--
CSS
============================================= -->

    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">

</head>

<body>

    <!-- Preloader -->
    <div id="loader-wrapper">
        <div id="loader"></div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>

    <!-- Start header section -->
    <header class="header-area" id="header-area">
        <div class="dope-nav-container breakpoint-off">
            <div class="container">
                <div class="row">
                    <!-- dope Menu -->
                    <nav class="dope-navbar justify-content-between" id="dopeNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html">
                            <img src="img/logo.png" alt="">
                        </a>

                        <!-- Navbar Toggler -->
                        <div class="dope-navbar-toggler">
                            <span class="navbarToggler">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </div>

                        <!-- Menu -->
                        <div class="dope-menu">

                            <!-- close btn -->
                            <div class="dopecloseIcon">
                                <div class="cross-wrap">
                                    <span class="top"></span>
                                    <span class="bottom"></span>
                                </div>
                            </div>

                            <!-- Nav Start -->
                            <div class="dopenav">
                                <ul id="nav">
                                    <li>
                                        <a href="index.html">Home</a>
                                    </li>
                                    <li>
                                        <a href="about-us.html">About Us</a>
                                    </li>
                                    <li>
                                        <a href="services.html">Services</a>
                                    </li>
                                    <li>
                                        <a href="#">Portfolio</a>
                                        <ul class="dropdown">
                                            <li><a href="portfolio.html">Portfolio</a></li>
                                            <li><a href="single-portfolio.html">Single Portfolio</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="#">Blog</a>
                                        <ul class="dropdown">
                                            <li><a href="blog.html">Blog List</a></li>
                                            <li><a href="single-blog.html">Single Blog</a></li>
                                        </ul>

                                    </li>
                                    <li>
                                        <a href="contact.html">Contact</a>
                                    </li>
                                </ul>

                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Start header section -->

    <!-- Start page-top-banner section -->
    <section class="page-top-banner section-gap-full relative" data-stellar-background-ratio="0.5">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row section-gap-half">
                <div class="col-lg-12 text-center">
                    <h1>Contact Us</h1>
                    <h4>Drop us Some Line</h4>
                </div>
            </div>
        </div>
    </section>
    <!-- End about-top-banner section -->

    <!-- Start contact section -->
    <section class="contact-section contact-page-section padding-top-120" id="contact-section">
        <div class="container">
            <div class="row address-wrap justify-content-center">
                <div class="col-lg-3 col-md-4 col-sm-6 single-address-col">
                    <div class="div">
                        <i class="ti ti-mobile"></i>
                        <p>
                            +880-176875479
                            <br> +880-754791768
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 single-address-col">
                    <div class="div">
                        <i class="ti ti-map-alt"></i>
                        <p>
                            1179 Sarah Drive,Lafayette
                            <br> California 90021
                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-12 single-address-col">
                    <div class="div">
                        <i class="ti ti-email"></i>
                        <p>
                            info@dopedemo.com
                            <br> contact@dopedemo.com
                        </p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center form-row">
                <div class="col-lg-9">
                    <form id="contact-form" action="#">
                        <div class="row contact-form-wrap justify-content-center">
                            <div class="col-md-6 contact-name form-col">
                                <input name="name" id="name" class="form-control" type="text" placeholder="Name*"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='Name*'">
                            </div>
                            <div class="col-md-6 contact-email form-col">
                                <input name="mail" id="mail" class="form-control" type="email" placeholder="E-mail*"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='Email*'">
                            </div>
                            <div class="col-lg-12">
                                <textarea name="comment" id="comment" class="form-control" rows="8" placeholder="Message"
                                    onfocus="this.placeholder=''" onblur="this.placeholder='Message*'"></textarea>
                            </div>
                            <input type="submit" class="primary-btn" value="Send Message" id="submit-message">
                            <div id="msg" class="message"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- End contact section -->

    <!-- Start footer section -->
    <footer class="footer-section section-gap-half">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 footer-cols">
                    <a href="#">
                        <img src="img/logo-w.png" alt="">
                    </a>
                    <p class="copyright-text">&copy; 2018 Design With
                        <i class="fa fa-heart" aria-hidden="true"></i> By <br>
                        <a href="http://dopetheme.com" target="_blank">Dope Theme</a>
                    </p>
                </div>
                <div class="col-lg-3 col-sm-6 footer-cols">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="index-multi.html">Home</a></li>
                        <li><a href="about-us.html">About Us</a></li>
                        <li><a href="service.html">Services</a></li>
                        <li><a href="portfolio.html">Portfolio</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 footer-cols">
                    <h4>Help</h4>
                    <ul>
                        <li><a href="#">Terms & condition</a></li>
                        <li> <a href="#">Privacy</a></li>
                        <li> <a href="#">Policy</a></li>
                        <li> <a href="#">Support</a></li>
                        <li> <a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 footer-cols">
                    <h4>Get in touch</h4>
                    <ul>
                        <li>
                            <a href="tel:880174230987">880174230987</a>
                        </li>
                        <li>
                            <a href="email:Support@dometheme.com.bd">Support@dometheme.com</a>
                        </li>
                        <li>
                            <a href="#">
                                West Baller court 69 <br>
                                London , UK
                            </a>
                        </li>
                    </ul>
                    <ul id="social">
                        <li>
                            <a target="_blank" href="#">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="#">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="#">
                                <i class="fa fa-google-plus"></i>
                            </a>
                        </li>
                        <li>
                            <a target="_blank" href="#">
                                <i class="fa fa-instagram" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- End footer section -->

    <div class="scroll-top">
        <i class="ti-angle-up"></i>
    </div>

    <!--
JS
============================================= -->
    <script src="js/vendor/jquery-2.2.4.min.js"></script>
    <script src="js/vendor/popper.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/jquery.parallax-scroll.js"></script>
    <script src="js/dopeNav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>